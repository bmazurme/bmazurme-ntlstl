import getAge from './getAge';

export default getAge;
