interface ILang {
  label: string,
  active: boolean,
}

export default ILang;

