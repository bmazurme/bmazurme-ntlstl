import ILang from './ILang';
import IProfile from './IProfile';

export type { ILang, IProfile };
