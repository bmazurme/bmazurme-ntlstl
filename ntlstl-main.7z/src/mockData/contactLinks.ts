const contactLinks = [
  {
    label: 'LinkedIn',
    link: 'https://www.linkedin.com/in/bogdan-mazur-aba74287',
  },
  {
    label: 'GitHub',
    link: 'https://github.com/bmazurme',
  },
];

export default contactLinks;
