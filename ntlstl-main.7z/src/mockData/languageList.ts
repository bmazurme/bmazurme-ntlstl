const languageList = [
  {
    label: 'RU',
    active: true,
  },
  {
    label: 'EN',
    active: false,
  },
];

export default languageList;
