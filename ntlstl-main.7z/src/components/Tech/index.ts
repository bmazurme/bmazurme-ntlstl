import Tech from './Tech';

export default Tech;
