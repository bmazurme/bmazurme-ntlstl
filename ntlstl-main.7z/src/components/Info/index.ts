import Info from './Info';

export default Info;
