import ContactMenu from './ContactMenu';

export default ContactMenu;
